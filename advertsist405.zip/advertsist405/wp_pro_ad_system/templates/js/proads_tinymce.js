(function() {
	
	/* TEXT EDITOR BUTTON */
    tinymce.create('tinymce.plugins.wpproads', {
        init : function(ed, url) {
			url = url.split('/templates/js');
			url = url[0];
            ed.addButton('wpproads_button', {
                title : 'WP Pro Advertising System Shortcode Editor',
                image : url+'/images/banner_icon_20.png',
                onclick : function() {
                     //ed.selection.setContent('[pre_ad adid="123"]' + ed.selection.getContent() + '[/pre_ad]');
					
					 var width = jQuery(window).width(), H = jQuery(window).height(), W = ( 720 < width ) ? 720 : width;
						W = W - 80;
						H = H - 84;
						tb_show( 'WP Pro Advertising System Shortcode Editor', '#TB_inline?width=' + W + '&height=' + H + '&inlineId=wpproads-shortcode-editor-form' );
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('wpproads', tinymce.plugins.wpproads);
	
	
	// executes this when the DOM is ready
	jQuery(function(){
		
		jQuery.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=load_wpproads_shortcodes",
		   success: function( msg ){
				
				var form = jQuery( msg );
				//var table = form.find('table');
				form.appendTo('body').hide();
				
				
				/* #Buttons
				================================================== */ 
				form.find('#adzone_submit').click(function(){
					var shortcode = '[pro_ad_display_adzone';
					
					if( jQuery('#adzone_id').val() != '' ){
						shortcode += ' id="' + jQuery('#adzone_id').val() + '"';
					}
					if( jQuery('#adzone_is_popup').val() == 1 ){
						shortcode += ' popup="1"';
					}
					if( jQuery('.adzone_popup_bg_color').val() != '' ){
						shortcode += ' popup_bg="'+ jQuery('.adzone_popup_bg_color').val() +'"';
					}
					if( jQuery('.adzone_popup_opacity').val() != '' ){
						shortcode += ' popup_opacity="'+ jQuery('.adzone_popup_opacity').val() +'"';
					}
					// Background
					if( jQuery('#adzone_is_background').val() == 1 ){
						shortcode += ' background="1"';
					}
					if( jQuery('.adzone_background_container').val() != '' ){
						shortcode += ' container="'+ jQuery('.adzone_background_container').val() +'"';
					}
					if( jQuery('.adzone_background_repeat').val() != '' ){
						shortcode += ' repeat="'+ jQuery('.adzone_background_repeat').val() +'"';
					}
					if( jQuery('.adzone_background_stretch').val() != '' ){
						shortcode += ' stretch="'+ jQuery('.adzone_background_stretch').val() +'"';
					}
					if( jQuery('.adzone_background_bg_color').val() != '' ){
						shortcode += ' bg_color="'+ jQuery('.adzone_background_bg_color').val() +'"';
					}
					
					shortcode += ']';
					
					// inserts the shortcode into the active editor
					tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode);
					
					// closes Thickbox
					tb_remove();
				});
				
				
				
			} // end success
			
		});
		
	});
	
})();



/*function wpm_html_entities(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, "'"); //'&quot;'
}*/