<?php
global $pro_ads_statistics, $pro_ads_main, $pro_ads_bs_templates;

$notice = array();

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if(isset($_POST['1']))
	{
		update_option( 'wpproads_custom_css', $_POST['wpproads_custom_css'] );
		update_option( 'wpproads_enable_stats', $_POST['wpproads_enable_stats']);
		update_option( 'wpproads_enable_userdata_stats', $_POST['wpproads_enable_userdata_stats']);
		$notice[] = __('General Settings are updated successfully.','wpproads');
	}
	elseif(isset($_POST['buyandsell_settings']))
	{
		update_option( 'buyandsell_paypal_email', $_POST['buyandsell_paypal_email'] );
		update_option( 'buyandsell_cur', $_POST['buyandsell_cur'] );
		update_option( 'buyandsell_order_screen_type', $_POST['buyandsell_order_screen_type'] );
		update_option( 'buyandsell_order_screen_url', $_POST['buyandsell_order_screen_url'] );
		$notice[] = __('Buy and Sell Settings are updated successfully.','wpproads');
	}
}


$custom_css = get_option('wpproads_custom_css', '');
$wpproads_enable_stats = get_option('wpproads_enable_stats', 0);
$wpproads_enable_userdata_stats = get_option('wpproads_enable_userdata_stats', 0);
?>

<div class="wrap ad_dashboard wpproads">
	
    <div class="ad_dasboard_boxes adheader">
    	<h3>WP PRO ADVERTISING SYSTEM</h3>
        <div class="version"><em><?php _e('Version','wpproads'); ?> <?php echo PAS()->version; ?></em></div>
    </div>
    <?php
	if( current_user_can(WP_ADS_ROLE_ADMIN))
	{
		?>
        <div class="ad_dasboard_boxes menu">
            <a href="post-new.php?post_type=advertisers" class="plus main_button" title="<?php _e('Add New','wpproads'); ?>">+</a><a href="edit.php?post_type=advertisers" class="main_button action_button"><?php _e('Advertisers','wpproads'); ?></a>
            <a href="post-new.php?post_type=campaigns" class="plus main_button" title="<?php _e('Add New','wpproads'); ?>">+</a><a href="edit.php?post_type=campaigns" class="main_button action_button"><?php _e('Campaigns','wpproads'); ?></a>
            <a href="post-new.php?post_type=banners" class="plus main_button" title="<?php _e('Add New','wpproads'); ?>">+</a><a href="edit.php?post_type=banners" class="main_button action_button"><?php _e('Banners','wpproads'); ?></a>
            <a href="post-new.php?post_type=adzones" class="plus main_button" title="<?php _e('Add New','wpproads'); ?>">+</a><a href="edit.php?post_type=adzones" class="main_button action_button"><?php _e('Adzones','wpproads'); ?></a>
        </div>
        <?php
	}
	?>
	
    <h2 class="messages-position"></h2>
    <?php
	// admin_notice Messages
    if( !empty($notice) )
	{
		foreach($notice as $note)
		{
			echo !empty($note) ? '<div class="updated wpproads-message"><p>'.$note.'</p></div>' : '';
		}
	}
	?>
    
    
    <div class="container">
    	<div class="left_content ad_dasboard_boxes">
         
            
            <div style="padding:20px;">
             
                <table id="tuna_tab_customization">
                    <tr>
                        <td valign="top">
                            <div id="tuna_tab_left">
                                <ul>
                                    
                                    <?php
                                    if($wpproads_enable_stats)
									{
										?>
                                        <li><a class="focused" data-target="statistics" title=""><?php _e("Today's statistics", 'wpproads'); ?></a></li>
										<?php
									}
									
									if( current_user_can(WP_ADS_ROLE_ADMIN))
									{
										?>
                                        <li><a <?php echo $wpproads_enable_stats ? '' : 'class="focused"'; ?> data-target="buyandsell-addon" title=""><?php _e('Buy and Sell Ads', 'wpproads'); ?></a></li>
                                        <li><a class="" data-target="manual-updates" title=""><?php _e('Manual Updates', 'wpproads'); ?></a></li>
                                        <li><a class="" data-target="general-settings" title=""><?php _e('General Settings', 'wpproads'); ?></a></li>
                                        <?php
									}
									?>
                                </ul>					
                            </div>
                        </td>
                        <td width="100%"  valign="top">
                            <div id="tuna_tab_right">
                                <p id="tuna_tab_arrow" style="top:4px"></p>
                                <div class="customization_right_in">
                                    
                                    <?php
									if($wpproads_enable_stats)
									{
										?>
                                        <div id="statistics" style="" class="nfer">
                                            <h2><?php _e("Today's Statistics", 'wpproads'); ?> <small style="font-size:12px; color:#999;"><em><?php echo date('l, F d', time()); ?></em></small></h2>
                                            <em class="hr_line"></em>
                                            <form action="" method="post" enctype="multipart/form-data">
                                                <div class="tuna_meta metabox-holder">
                                    
                                                    <div class="postbox nobg">
                                                        <div class="inside">
                                                            
                                                            <!-- Toadays statistics -->
                                                            <div class="dashboard_stats ad_dasboard_boxes">
                                                                
                                                                <?php 
                                                                    echo $pro_ads_statistics->pro_ad_show_statistics_header( 
                                                                            array( 
                                                                                'text'  => array(
                                                                                    'click' => __('Clicks','wpproads'),
                                                                                    'impr'  => __('Impressions','wpproads'),
                                                                                    'ctr'   => __('CTR','wpproads'),
                                                                                ), 
                                                                                'rid'   => 4, 
                                                                                'day'   => date('d'), 
                                                                                'month' => date('m'), 
                                                                                'year'  => date('Y')
                                                                            ) 
                                                                        ); 
                                                                ?>
                                                                <a href="?page=wp-pro-ads-stats" class="main_button"><?php _e('Check all statistics','wpproads'); ?></a>
                                                            </div>
                                                            <!-- end Toadays statistics -->
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <?php
									}
                                   
									
									if( current_user_can(WP_ADS_ROLE_ADMIN))
									{
										?>
										<div id="buyandsell-addon" <?php echo $wpproads_enable_stats ? 'style="display:none;"' : ''; ?> class="nfer">
                                            <h2><?php echo !$pro_ads_main->buyandsell_is_active() ? __('Buy and Sell Ads', 'wpproads') : __('Buy and Sell Ads, Settings', 'wpproads'); ?></h2>
                                            <em class="hr_line"></em>
                                                <div class="tuna_meta metabox-holder">
                                    
                                                    <div class="postbox nobg">
                                                        <div class="inside">
                                                            <table class="form-table">
                                                                <tbody>
                                                                    <tr>
                                                                        <td colspan="2">
                                                                            
                                                                            <?php
                                                                            if( !$pro_ads_main->buyandsell_is_active() )
                                                                            {
                                                                                ?>
                                                                                <div style="float:left; width:150px; height:100px; background:#F3F3F3; border:solid 1px #EDEDED; margin:0 10px 0;">
                                                                                    <div style="text-align:center; padding-top:40px;">
                                                                                        <a href="http://bit.ly/buyandsellads" style="text-decoration:none; color:#999;" target="_blank"><?php _e('Advertise Here','wpproads'); ?></a>
                                                                                    </div>
                                                                                </div> 
                                                                                Make sure your adzones do not remain empty! Let users buy advertisments directly on your website! The Buy and Sell Add-on turns your empty adzones into links where users can instantly upload their banner, pay and activate their advertisement on your website.
                                                                                
                                                                                <div class="clearFix"></div>
                                                                                <br /><br />
                                                                                <a href="http://bit.ly/buyandsellads" class="main_button" target="_blank"><?php _e('Download Buy and Sell Ads - ADD-ON','wpproads'); ?></a>
                                                                                <?php
                                                                            }
                                                                            else
                                                                            {
                                                                                $pro_ads_bs_templates->pro_ad_buy_and_sell_settings();
                                                                            }
                                                                            ?>
                                                                            <span class="description manual_update_info"><?php _e('','wpproads'); ?></span>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <!-- end .postbox -->
                                                </div>
                                                <!-- end .tuna_meta -->
                                                
                                        </div>
                                        <!-- end #buyandsell-addon -->
									
									
                                    
                                    
									
                                        <div id="manual-updates" style="display:none;" class="nfer">
                                            <h2><?php _e('Manual Updates', 'wpproads'); ?></h2>
                                            <em class="hr_line"></em>
                                                <div class="tuna_meta metabox-holder">
                                    
                                                    <div class="postbox nobg">
                                                        <div class="inside">
                                                            <table class="form-table">
                                                                <tbody>
                                                                    <tr>
                                                                        <td colspan="2">
                                                                            
                                                                            <?php _e('Campaign and Banner statuses get updated once a day automatically. If you want to, you can manually Finish or Start campaigns by clicking the update button.','wpproads'); ?>
                                                                            <br /><br />
                                                                            <a href="javascript:void(0)" id="manual_update_campaings_banners" class="main_button"><?php _e('Update Campaigns/Banners','wpproads'); ?></a>
                                                                            <span class="description manual_update_info"><?php _e('','wpproads'); ?></span>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <!-- end .postbox -->
                                                </div>
                                                <!-- end .tuna_meta --> 
                                        </div>
                                        <!-- end #manual-updates -->
                                        
                                        
                                        
                                        
                                        
                                        <div id="general-settings" style="display:none;" class="nfer">
                                            <h2><?php _e('General Settings', 'wpproads'); ?></h2>
                                            <em class="hr_line"></em>
                                            <form action="" method="post" enctype="multipart/form-data">
                                                <div class="tuna_meta metabox-holder">
                                    
                                                    <div class="postbox nobg">
                                                        <div class="inside">
                                                            <table class="form-table">
                                                                <tbody>
                                                                    <tr>
                                                                        <th scope="row">
                                                                            <?php _e( "Enalbe Satistics", 'wpproads' ); ?>
                                                                            <span class="description"><?php _e('Do you want statistics to be saved?', 'wpproads'); ?></span>
                                                                        </th>
                                                                        <td>
                                                                            <select id="wpproads_enable_stats" name="wpproads_enable_stats">
                                                                                <option value="0" <?php echo empty($wpproads_enable_stats) ? 'selected' : ''; ?>>
                                                                                    <?php _e('No', 'wpproads'); ?>
                                                                                </option>
                                                                                <option value="1" <?php echo $wpproads_enable_stats ? 'selected' : ''; ?>>
                                                                                    <?php _e('Yes', 'wpproads'); ?>
                                                                                </option>
                                                                            </select>
                                                                            <span class="description"></span>
                                                                        </td>
                                                                    </tr>
                                                                    <tr id="enable_userdata_stats" <?php echo !empty($wpproads_enable_stats) ? '' : 'style="display:none;"'; ?>>
                                                                        <th scope="row">
                                                                            <?php _e( "Enalbe User data stats", 'wpproads' ); ?>
                                                                            <span class="description"><?php _e('Do you want specific user data for statistics to be saved?', 'wpproads'); ?></span>
                                                                        </th>
                                                                        <td>
                                                                            <select id="wpproads_enable_userdata_stats" name="wpproads_enable_userdata_stats">
                                                                                <option value="0" <?php echo empty($wpproads_enable_userdata_stats) ? 'selected' : ''; ?>>
                                                                                    <?php _e('No', 'wpproads'); ?>
                                                                                </option>
                                                                                <option value="1" <?php echo $wpproads_enable_userdata_stats ? 'selected' : ''; ?>>
                                                                                    <?php _e('Yes', 'wpproads'); ?>
                                                                                </option>
                                                                            </select>
                                                                            <span class="description"></span>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th scope="row">
                                                                            <?php _e('Custom CSS', 'wpproads'); ?>
                                                                            <span class="description"><?php _e('If you need to customize some style for the Ads plugin you can add the custom CSS here.','wpproads'); ?></span>
                                                                        </th>
                                                                        <td>
                                                                            <textarea id="wpproads_custom_css" class="ivc_input" style="height:100px; margin:10px 0 0 0;" name="wpproads_custom_css"><?php echo $custom_css; ?></textarea>
                                                                            <span class="description"><?php _e('','wpproads'); ?></span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <!-- end .postbox -->
                                                </div>
                                                <!-- end .tuna_meta -->
                                                        
                                                
                                                <div class="btn_container_with_menu" style="margin-top:40px;">
                                                    <input type="submit" value="<?php _e('Save General Settings', 'wpproads'); ?>" class="main_button" name="1" />
                                                </div>
                                            </form>
                                        </div>
                                        <!-- end #general-settings -->
                                        <?php
									}
									?>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                </div>
                                <!-- end .customization_right_in -->
                            </div>
                            <!-- end #tuna_tab_right -->
                        </td>
                    </tr>
                </table>
                
                
                
            </div> <!-- end tablist -->
            
            
            
            
            
            
            
            
        	
        </div>
        <div class="sidebar ad_dasboard_boxes">
        	
            <div class="content">
            	<h2><?php _e('New version','wpproads'); ?> <small style="font-size:12px; color:#999;"><em><?php echo PAS()->version; ?></em></small></h2>
                <p>
                	Thanks for using the completely renewed <?php echo current_user_can(WP_ADS_ROLE_ADMIN) ? '"WP PRO ADVERTISING"' : '"WP PRO ADVERTISING SYSTEM"'; ?> plugin. We hope you like it. 
                </p>
            </div>
            
        </div>
    </div>
    
</div>
<!-- end wrap -->


<script type='text/javascript'>
jQuery(document).ready(function($) {
    
    // switching between tabs
	$('#tuna_tab_left').find('a').click(function(){
		
		var nfer_id = $(this).data('target');
		
		$('.nfer').hide();
		$('#'+nfer_id).show();
		
		change_tab_position($(this));
		
		//window.location.hash = nfer_id;
		return false;
		
	});
	// position of the arrow
	function change_tab_position(obj){

		// class switch
		$('#tuna_tab_left').find('a').removeClass('focused');
		obj.addClass('focused');

		var menu_position = obj.position();
		$('#tuna_tab_arrow').css({'top':(menu_position.top+3)+'px'}).show();
	}
    
});
</script>