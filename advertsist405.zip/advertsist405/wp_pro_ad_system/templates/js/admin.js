jQuery(document).ready(function($) {

	$('.chosen-select').chosen(); 
	$('#filter-by-date').chosen();
	
	$("#start_date").datepicker({dateFormat: 'mm.dd.yy', minDate: 0});
	$("#end_date").datepicker({dateFormat: 'mm.dd.yy', minDate: -1});
	
	
	$(".chosen-select.select-adzone").on('change', function(event, params) {
		
		// Get the banner id
		if( params.deselected ){
			bid = $('option[value="'+ params.deselected +'"]', this).attr('bid');
			aid = $('option[value="'+ params.deselected +'"]', this).val();
			action_type = 'remove'; 
		}else{
			bid = $('option[value="'+ params.selected +'"]', this).attr('bid');
			aid = $('option[value="'+ params.selected +'"]', this).val();
			action_type = 'add'; 
		}
		
		$('.select-adzone-cont-'+bid).css({'opacity': .3});
		$('.loading_adzone_'+bid).show();
		
		// Get all selected options
		var result = "";
		$('.select-adzone-'+bid+' option:selected').each(function(i, item){ 
			
			comma = i == 0 ? "" : ",";
			result += comma+$(this).val();
		});
		
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=link_to_adzone&aid="+ aid +"&bid="+bid +"&result=" + result +"&action_type="+ action_type,
		   success: function( msg ){
				
				//alert(msg);
				$('.loading_adzone_'+bid).hide();
				$('.select-adzone-cont-'+bid).css({'opacity': 1});
		   }
		});
		
	});
	

	
	$(".select_banner_advertiser").change(function() {
		
		$('.hide_row').hide();
		
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=load_advertiser_campaigns&uid="+ $(this).val(),
		   success: function( msg ){
				
				$('.hide_row').show();
				$('#select_cont').html( msg );
				$('.chosen-select').chosen(); 
		   }
		});
	});
	
	$("#filter_advertisers").change(function() {
		
		//$('.hide_row').hide();
		
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=filter_advertiser_campaigns&uid="+ $(this).val(),
		   success: function( msg ){
				
				//$('.hide_row').show();
				$('#select_cont').html( msg );
				$('.chosen-select').chosen(); 
		   }
		});
	});


	
	/*
	 * Media Popup - works for admins only
	*/
	$('.upload_image_button').on('click', function()
	{
		wp.media.editor.send.attachment = function(props, attachment)
		{
			$('#banner_url').val(attachment.url);
			//$('#banner-img-preview').html('<img src="'+attachment.url+'" width="25" />');
			$('#banner-img-preview').attr("src",attachment.url);
		}
		wp.media.editor.open(this);
		
		return false;
	});
	/*
	var formfield;
	jQuery('.upload_image_button').click(function() {
	
		jQuery('html').addClass('Image');
		formfield = jQuery(this).prev().attr('name');
		tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
		return false;
		});
		window.original_send_to_editor = window.send_to_editor;
		window.send_to_editor = function(html){
		if (formfield) {
			fileurl = jQuery('img',html).attr('src');
			jQuery('#'+formfield).val(fileurl);
			tb_remove();
			jQuery('html').removeClass('Image');
		} else {
			window.original_send_to_editor(html);
		}
				
		var img_preview = jQuery('#banner_url').val();
		jQuery('#banner-img-preview').attr("src",img_preview);
	};*/
	
	
	
	
	
	$('#size_list').change(function(){
	
		var val = $('#size_list').val();
		if( val == 'custom'){
			$('#custom_size').show();
		}else{
			$('#custom_size').hide();
		}
	});
	
	$('#wpproads_enable_stats').change(function(){
		
		var val = $('#wpproads_enable_stats').val();
		if( val == '1'){
			$('#enable_userdata_stats').show();
		}else{
			$('#enable_userdata_stats').hide();
		}
	});
	
	
	
	var txt = $('#banner_contract option:selected').attr('txt');
	$('.banner_contract_duration').html(txt);
	
	if( $('#banner_contract option:selected').val() == 0 ){
		$('#banner_duration_tr').hide();
	}else{
		$('#banner_duration_tr').show();
	}
	
	$('#banner_contract').change(function(){
	
		var val = $('#banner_contract').val();
		var txt = $('#banner_contract option:selected').attr('txt');
		
		$('.banner_contract_duration').html(txt);
		
		if( $('#banner_contract option:selected').val() == 0 ){
			$('#banner_duration_tr').hide();
		}else{
			$('#banner_duration_tr').show();
		}
	});
	
	
	
	
	// Sortable banners in adzones
	$('ul#adzone_order_sortable').sortable({
        axis: 'y',
		placeholder: "ui-state-highlight",
        stop: function (event, ui) {
	        //var postdata = $(this).sortable('serialize');
			var id_order = $(this).sortable('toArray', {attribute: 'bid'});
			var adzone_id = $(this).attr('aid');
			
			$('.order_banners_'+adzone_id).css({ 'opacity':.5 });
			$('.order_banners_'+adzone_id+' .loading').show();
			
           	$.ajax({
                type: 'POST',
                url: ajaxurl,
				data: 'action=order_banners_in_adzone&aid='+adzone_id+'&id_order='+id_order,
				success: function( msg ){
				
					//alert(msg);
					$('.order_banners_'+adzone_id+' .loading').hide();
					$('.order_banners_'+ adzone_id).css({ 'opacity':1 });
			   }
            });
		}
    });
	
	
	
	
	
	// Statistics
	//$('.stats_btn').on('click', function(){
	$("body").on("click", "a.stats_btn", function(event){
		
		$('.pro_ad_stats_graph').css({opacity: .3});
		
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=load_stats&type="+ $(this).attr('type') +"&name="+ $(this).text() +"&color="+ $(this).attr('color')+"&rid="+$(this).attr('rid')+"&year="+ $(this).attr('year')+"&month="+ $(this).attr('month')+"&day="+ $(this).attr('day'),
		   success: function( msg ){
				
				$('.pro_ad_stats_graph').html(msg);
				$('.pro_ad_stats_graph').css({opacity: 1});
		   }
		});
		
	});
	
	
	
	$("body").on("click", "a.stats_date", function(event){
	//$('.stats_date').on('click', function(){
		
		$('.pro_ad_stats_graph').css({opacity: .3});
		
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=load_stats_from_day&type="+ $(this).attr('type') +"&color="+$(this).attr('color')+"&year="+ $(this).attr('year')+"&month="+ $(this).attr('month')+"&day="+ $(this).attr('day'),
		   success: function( msg ){
				
				$('.pro_ad_stats_graph').html(msg);
				$('.pro_ad_stats_graph').css({opacity: 1});
		   }
		});
		
	});
	
	
	$("body").on("click", "a.time_frame_btn", function(event){
		
		$('.pro_ad_stats_graph').css({opacity: .3});
		var type = $(this).attr('type') != '' && $(this).attr('type') != null ? $(this).attr('type') : 'click';
		
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=load_stats&type="+type+"&name=Clicks&rid="+$(this).attr('rid')+"&year="+ $(this).attr('year')+"&month="+ $(this).attr('month'),
		   success: function( msg ){
				
				$('.pro_ad_stats_graph').html(msg);
				$('.pro_ad_stats_graph').css({opacity: 1});
		   }
		});
		
	});
	
	
	
	
	
	/* Update Campaigns/Banners (dashboard) */
	//$("#manual_update_campaings_banners").on('click', function(){
	$("body").on("click", "#manual_update_campaings_banners", function(event){
		
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=manual_update_campaigns_banners",
		   success: function( msg ){
				
				$('.manual_update_info').html( msg );
		   }
		});
		
	});
	
	
});
	