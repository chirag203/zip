var paspopupStatus = 0; // set value

function PASfunctions(){
jQuery(function($){

	/* ----------------------------------------------------------------
	 * POPUP
	 * ---------------------------------------------------------------- */
	$("body").on("click", "a.paspopup", function(event){
		//alert('klik')
		var adzone_id = $(this).attr('adzone_id');
		var popup_type = $(this).attr('popup_type');
		var ajaxurl = $(this).attr('ajaxurl');
		
		setTimeout(function(){ 
			loadPASPopup( adzone_id, popup_type, ajaxurl ); // function show popup
		}, 0); // 500 = .5 second delay
	return false;
	});


	$("body").on("click", "div.close_paspopup", function(event){	
		disablePASPopup();  // function close pop up
	});

	$(this).keyup(function(event) {
		if (event.which == 27) { // 27 is 'Ecs' in the keyboard
			disablePASPopup();  // function close pop up
		}
	});
		
	$("body").on("click", "div#backgroundPasPopup", function(event){		
		disablePASPopup();  // function close pop up
	});
	
	
	
	
	
	/* ----------------------------------------------------------------
	 * BACKGROUND ADS
	 * ---------------------------------------------------------------- */
	// Redirect to banner url when pas_container is clicked
	//$(clickable_paszone.pas_container).on('click', function(event){
	$("body").on('click', function(event){
		
		var target = $(event.target);
		var target_id = event.target.id;

		// When user hovers the clickable adzones
		if (target.is(clickable_paszone.pas_container) || target_id == clickable_paszone.pas_container){
			
			// Add links to left and right sides
			if (clickable_paszone.link_full == "" || clickable_paszone.link_full == null){
				var width = $(document).width();

				if (event.pageX <= (width / 2)){
					// Left side
					var adlink = window.open(clickable_paszone.link_left, clickable_paszone.link_left_target);
				}else{
					// Right side
					var adlink = window.open(clickable_paszone.link_right, clickable_paszone.link_right_target);
				}
			}else{
				// Add link to both sides
				var adlink = window.open(clickable_paszone.link_full, clickable_paszone.link_full_target);
			}
			adlink.focus();
		}
	});
	// Change cursor to pointer when hovering over pas_container adzones
	$(document).mousemove(function(event){
		var target = $( event.target );
		var target_id = event.target.id;
		
		if(target.is(clickable_paszone.pas_container) || target_id == clickable_paszone.pas_container){
			target.css('cursor', 'pointer');
			$('#'+target_id).css('cursor', 'pointer');
		}else{
			$(clickable_paszone.pas_container).css('cursor','auto');
			$('#'+clickable_paszone.pas_container).css('cursor','auto');
		}
	});
	


});
}

jQuery(document).ready(function($){
	var pas_function = new PASfunctions();
});


/************** start: functions. **************/
function loadPASPopup( adzone_id, popup_type, ajaxurl ) {

	jQuery(function($){
	if(paspopupStatus == 0) { // if value is 0, show popup
		
		$(".PasPopupCont").fadeIn(0500); // fadein popup div
		//$("#backgroundPasPopup").css("opacity", "0.7"); // css opacity, supports IE7, IE8
		$("#backgroundPasPopup").fadeIn(0001);
		paspopupStatus = 1; // and set value to 1
		/*
		$.ajax({
		   type: "POST",
		   url: ajaxurl,
		   data: "action=buyandsell_popup_ajax_content&adzone_id="+adzone_id+"&popup_type="+popup_type,
		   success: function( msg ){
				//$('.hide_row').show();
				$('.pro_ads_buyandsell_'+popup_type+'_popup_'+adzone_id+'_ajax_content').html( msg );
				
				// Activate Ajax Uploads
				if(popup_type == 'buy'){
					load_ajax_upload(ajaxurl);
					
				}
		   }
		});
		*/
	}
	
	});
}

function disablePASPopup() {
	jQuery(function($){
		
	if(paspopupStatus == 1) { // if value is 1, close popup
		
		$(".PasPopupCont").fadeOut("normal");
		$("#backgroundPasPopup").fadeOut("normal");
		paspopupStatus = 0;  // and set value to 0
	}
	
	});
}
/************** end: functions. **************/
